var searchData=
[
  ['ratio',['ratio',['../struct_cjt__problemas_1_1prat.html#abc19a891cf42bf745b1d0e9736e7ca80',1,'Cjt_problemas::prat']]]
];
