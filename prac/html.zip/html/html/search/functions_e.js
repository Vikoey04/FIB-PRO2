var searchData=
[
  ['vect_5fproblemas',['vect_problemas',['../class_sesion.html#a9ed9478b2d860d8d713e19823febeaf3',1,'Sesion']]]
];
