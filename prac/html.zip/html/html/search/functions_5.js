var searchData=
[
  ['ha_5fresuelto_5fproblema',['ha_resuelto_problema',['../class_usuario.html#a6f9608eac6a6a05d850dcad07bdf37f3',1,'Usuario']]],
  ['ha_5fterminado',['ha_terminado',['../class_usuario.html#aae8ff05308f5cc1e5f4267c577da386e',1,'Usuario']]]
];
