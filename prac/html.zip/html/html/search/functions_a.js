var searchData=
[
  ['primera',['primera',['../class_sesion.html#ac5cabac266d233381c6c94391fe85769',1,'Sesion']]],
  ['problema',['Problema',['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema']]],
  ['problemas_5fenviables',['problemas_enviables',['../class_cjt__sesiones.html#a52b36f12479444065510c1acfb235dfe',1,'Cjt_sesiones::problemas_enviables()'],['../class_cjt__usuarios.html#a60b4396cdd65a2aa4b7a8706dabbe08b',1,'Cjt_usuarios::problemas_enviables()'],['../class_sesion.html#a277a3775d1e19373e3ca507b819b5cc8',1,'Sesion::problemas_enviables()'],['../class_usuario.html#a79c8b5d178c8cfe7604210dc38d41fa1',1,'Usuario::problemas_enviables()']]],
  ['problemas_5fresueltos',['problemas_resueltos',['../class_cjt__usuarios.html#a08ce8035512646dec31f4959dc8aa891',1,'Cjt_usuarios::problemas_resueltos()'],['../class_usuario.html#a11b719ee95e8089a4f34c172c81f2a5b',1,'Usuario::problemas_resueltos()']]]
];
