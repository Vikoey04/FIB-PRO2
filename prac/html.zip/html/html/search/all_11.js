var searchData=
[
  ['vect_5fp',['vect_p',['../class_sesion.html#ab9459a157fdb5e1c2f975ba20305ae8f',1,'Sesion']]],
  ['vect_5fproblemas',['vect_problemas',['../class_sesion.html#a9ed9478b2d860d8d713e19823febeaf3',1,'Sesion']]]
];
