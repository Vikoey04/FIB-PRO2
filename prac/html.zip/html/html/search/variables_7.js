var searchData=
[
  ['sesiones',['sesiones',['../class_cjt__sesiones.html#a87e835a62e561eeb0f93eedbdcbe1802',1,'Cjt_sesiones::sesiones()'],['../class_curso.html#acd47bc8fe2f8121284246241d1e1dab5',1,'Curso::sesiones()']]]
];
