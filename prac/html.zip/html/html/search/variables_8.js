var searchData=
[
  ['t',['t',['../class_problema.html#a968bd889d6dc627efb59318ccc2eed7d',1,'Problema']]]
];
