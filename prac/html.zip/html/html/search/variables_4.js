var searchData=
[
  ['id',['id',['../struct_cjt__problemas_1_1prat.html#a6d97326c9213c837aa9bff8159ffa061',1,'Cjt_problemas::prat']]],
  ['inscritos',['inscritos',['../class_curso.html#aef03f588dd91d57a6e679d05148fd971',1,'Curso']]]
];
