var searchData=
[
  ['ratio',['ratio',['../struct_cjt__problemas_1_1prat.html#abc19a891cf42bf745b1d0e9736e7ca80',1,'Cjt_problemas::prat::ratio()'],['../class_problema.html#a8b41092b4207375e9f1bb4e29b9d4535',1,'Problema::ratio()']]]
];
