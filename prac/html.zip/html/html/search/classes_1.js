var searchData=
[
  ['prat',['prat',['../struct_cjt__problemas_1_1prat.html',1,'Cjt_problemas']]],
  ['problema',['Problema',['../class_problema.html',1,'']]]
];
