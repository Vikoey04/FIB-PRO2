var searchData=
[
  ['act_5fenviables',['act_enviables',['../class_sesion.html#a7e64b66ecf1ad363dd0c394ec59eaa91',1,'Sesion']]],
  ['act_5fenviables_5fi',['act_enviables_i',['../class_sesion.html#ad391d505577569f30635f19a0f36c9a0',1,'Sesion']]],
  ['act_5fenvios',['act_envios',['../class_cjt__problemas.html#abb0defe688a1012b27eddc463b53bf18',1,'Cjt_problemas::act_envios()'],['../class_problema.html#a7867d1ae1e09f424283feae8c5b636c8',1,'Problema::act_envios()']]],
  ['act_5fproblemas_5fenviables',['act_problemas_enviables',['../class_cjt__sesiones.html#a643292089a9534d7eea048df779e00fd',1,'Cjt_sesiones::act_problemas_enviables()'],['../class_sesion.html#a0fc0dfafa8e3bd98e7d18dff68eb82f2',1,'Sesion::act_problemas_enviables()']]],
  ['agregar_5fproblema_5fdisp',['agregar_problema_disp',['../class_usuario.html#a4dedcdcfe3d1769d6d2106d9fb2f7e51',1,'Usuario']]],
  ['alta',['alta',['../class_cjt__cursos.html#a974c8ac07471f9354fb13616a489f726',1,'Cjt_cursos::alta()'],['../class_curso.html#a70a7c89d56e2cfea52079990808c57c3',1,'Curso::alta()']]],
  ['alta_5fusuario',['alta_usuario',['../class_cjt__usuarios.html#af2bc90f54125530ce07dde609dfbe43b',1,'Cjt_usuarios']]]
];
