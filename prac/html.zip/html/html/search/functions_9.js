var searchData=
[
  ['nueva_5fsesion',['nueva_sesion',['../class_cjt__sesiones.html#a7436186b6a6b34354ab5303f6b8bcfa9',1,'Cjt_sesiones']]],
  ['nuevo_5fcurso',['nuevo_curso',['../class_cjt__cursos.html#ae2e0a96f014dda94b0d8465838cf14b6',1,'Cjt_cursos']]],
  ['nuevo_5fproblema',['nuevo_problema',['../class_cjt__problemas.html#a6c84adcab542d776e02f851eb9d3da82',1,'Cjt_problemas']]],
  ['num_5fproblemas',['num_problemas',['../class_cjt__problemas.html#aa713f6541f4d9b67497f047806a8374e',1,'Cjt_problemas::num_problemas()'],['../class_cjt__sesiones.html#a25fab9688073ad869f8e8f53445955d6',1,'Cjt_sesiones::num_problemas()'],['../class_sesion.html#a32dcea163badd79a3ffe111957741de9',1,'Sesion::num_problemas()']]],
  ['num_5fsesiones',['num_sesiones',['../class_cjt__cursos.html#a3a8c9c5eecbdab5e1702233dab4d725b',1,'Cjt_cursos::num_sesiones()'],['../class_cjt__sesiones.html#afd0955b255bea0e7e8f9a7be5156e5fc',1,'Cjt_sesiones::num_sesiones()'],['../class_curso.html#a1cf7c335137c295ea160a9682c10c07a',1,'Curso::num_sesiones()']]],
  ['num_5fusuarios',['num_usuarios',['../class_cjt__usuarios.html#ab4351f7ee85af8de0f7387fc55d29755',1,'Cjt_usuarios::num_usuarios()'],['../class_curso.html#a8141469f11a8e4431540314577d4bee2',1,'Curso::num_usuarios()']]]
];
