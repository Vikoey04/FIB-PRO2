var searchData=
[
  ['sesion',['Sesion',['../class_sesion.html#adf5a84efa8e2629b30ad89df74cfc0a2',1,'Sesion::Sesion()'],['../class_cjt__sesiones.html#a9e0c9082d6baad2a6ab002fcbfefc8ea',1,'Cjt_sesiones::sesion()']]],
  ['sesion_5fproblema',['sesion_problema',['../class_cjt__cursos.html#acc9074c9338d31947bdd84e3498580be',1,'Cjt_cursos::sesion_problema()'],['../class_curso.html#ac70e956fb7a0511e5fbdd097a689b69f',1,'Curso::sesion_problema()']]]
];
