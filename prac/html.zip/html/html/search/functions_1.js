var searchData=
[
  ['baja',['baja',['../class_cjt__cursos.html#a01b47ced7b3b96ea87775bb4e2f0302a',1,'Cjt_cursos::baja()'],['../class_curso.html#a446950b19d03260dacc9f7d5f8e98f21',1,'Curso::baja()']]],
  ['baja_5fusuario',['baja_usuario',['../class_cjt__usuarios.html#a318dcc3682784e73e0fe98ddbf39350c',1,'Cjt_usuarios']]]
];
